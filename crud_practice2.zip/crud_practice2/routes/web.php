<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

Route::get('/', [ProductController::class, 'index'])->name('home');
Route::get('/add-product', [ProductController::class, 'addProduct'])->name('add');
Route::get('/manage-product', [ProductController::class, 'manageProduct'])->name('manage');
