@extends('master')

@section('title')
    Home
@endsection

@section('body')
    <h5>Hello World</h5>
@endsection
