<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-center">Add Product</h4>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(('')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Product Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="product_name">
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Product Category</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="product_category">
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Brand Name</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="brand_name">
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Product Price</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="product_price">
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Product Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="product_image">
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <label class="col-md-3">Product Description</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="product_description" id="" cols="30" rows="10"></textarea>
                                    </div>
                                </div>

                                <div class="form-group row mt-3">
                                    <input type="submit" class="btn btn-success btn-block" value="Add Product">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH N:\Xampp\htdocs\practice\crud_practice2\resources\views/product/add.blade.php ENDPATH**/ ?>